package com.praktica.praktica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrakticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
